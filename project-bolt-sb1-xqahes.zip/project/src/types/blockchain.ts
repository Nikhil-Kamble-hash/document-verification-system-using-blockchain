export interface Block {
  index: number;
  timestamp: number;
  data: {
    fileName: string;
    hash: string;
    owner: string;
  };
  previousHash: string;
  hash: string;
  nonce: number;
}

export interface VerificationResult {
  isValid: boolean;
  message: string;
  block?: Block;
}