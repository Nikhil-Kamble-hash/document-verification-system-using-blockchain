import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import { VerificationResult as IVerificationResult } from '../types/blockchain';

interface VerificationResultProps {
  result: IVerificationResult | null;
}

export const VerificationResult: React.FC<VerificationResultProps> = ({ result }) => {
  if (!result) return null;

  return (
    <div className={`mt-6 p-4 rounded-lg ${
      result.isValid ? 'bg-green-50' : 'bg-red-50'
    }`}>
      <div className="flex items-center space-x-3">
        {result.isValid ? (
          <CheckCircle className="w-6 h-6 text-green-500" />
        ) : (
          <XCircle className="w-6 h-6 text-red-500" />
        )}
        <div>
          <h3 className={`font-medium ${
            result.isValid ? 'text-green-800' : 'text-red-800'
          }`}>
            {result.isValid ? 'Document Verified' : 'Verification Failed'}
          </h3>
          <p className={`text-sm ${
            result.isValid ? 'text-green-600' : 'text-red-600'
          }`}>
            {result.message}
          </p>
        </div>
      </div>
    </div>
  );
};