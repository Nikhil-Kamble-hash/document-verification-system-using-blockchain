import React from 'react';
import { Block } from '../types/blockchain';
import { Clock, File, Hash, User } from 'lucide-react';

interface BlockchainExplorerProps {
  blocks: Block[];
}

export const BlockchainExplorer: React.FC<BlockchainExplorerProps> = ({ blocks }) => {
  return (
    <div className="w-full max-w-4xl">
      <h2 className="text-2xl font-bold mb-6">Blockchain Explorer</h2>
      <div className="space-y-4">
        {blocks.map((block) => (
          <div
            key={block.hash}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Hash className="w-4 h-4" />
                  <span className="font-mono text-sm">Block #{block.index}</span>
                </div>
                <div className="mt-2 flex items-center space-x-2">
                  <File className="w-4 h-4 text-blue-500" />
                  <span className="font-medium">{block.data.fileName}</span>
                </div>
                <div className="mt-2 flex items-center space-x-2">
                  <User className="w-4 h-4 text-green-500" />
                  <span>{block.data.owner}</span>
                </div>
                <div className="mt-2 flex items-center space-x-2 text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>{new Date(block.timestamp).toLocaleString()}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="font-semibold">Hash:</span>
                  <p className="font-mono text-xs break-all">{block.hash}</p>
                </div>
                <div className="text-sm">
                  <span className="font-semibold">Previous Hash:</span>
                  <p className="font-mono text-xs break-all">{block.previousHash}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};