import React, { useCallback } from 'react';
import { Upload } from 'lucide-react';
import SHA256 from 'crypto-js/sha256';

interface FileUploadProps {
  onFileHash: (fileName: string, hash: string) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileHash }) => {
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result;
      const hash = SHA256(content as string).toString();
      onFileHash(file.name, hash);
    };
    reader.readAsText(file);
  }, [onFileHash]);

  return (
    <div className="w-full max-w-md">
      <label
        htmlFor="file-upload"
        className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors"
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <Upload className="w-12 h-12 mb-4 text-gray-500" />
          <p className="mb-2 text-sm text-gray-500">
            <span className="font-semibold">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-gray-500">Any file to verify</p>
        </div>
        <input
          id="file-upload"
          type="file"
          className="hidden"
          onChange={handleFileUpload}
        />
      </label>
    </div>
  );
};