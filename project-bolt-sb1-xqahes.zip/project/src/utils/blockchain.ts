import SHA256 from 'crypto-js/sha256';
import { Block } from '../types/blockchain';

export const calculateHash = (
  index: number,
  previousHash: string,
  timestamp: number,
  data: any,
  nonce: number
): string => {
  return SHA256(
    index + previousHash + timestamp + JSON.stringify(data) + nonce
  ).toString();
};

export const createGenesisBlock = (): Block => {
  const block = {
    index: 0,
    timestamp: new Date().getTime(),
    data: {
      fileName: 'Genesis Block',
      hash: 'genesis',
      owner: 'System'
    },
    previousHash: '0',
    nonce: 0,
    hash: ''
  };
  
  block.hash = calculateHash(
    block.index,
    block.previousHash,
    block.timestamp,
    block.data,
    block.nonce
  );
  
  return block;
};

export const mineBlock = (previousBlock: Block, data: any): Block => {
  const newBlock: Block = {
    index: previousBlock.index + 1,
    timestamp: new Date().getTime(),
    data,
    previousHash: previousBlock.hash,
    nonce: 0,
    hash: ''
  };

  // Simple proof of work (find a hash starting with '00')
  while (true) {
    newBlock.hash = calculateHash(
      newBlock.index,
      newBlock.previousHash,
      newBlock.timestamp,
      newBlock.data,
      newBlock.nonce
    );
    if (newBlock.hash.substring(0, 2) === '00') break;
    newBlock.nonce++;
  }

  return newBlock;
};