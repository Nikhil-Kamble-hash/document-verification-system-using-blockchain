import React, { useState, useCallback } from 'react';
import { FileUpload } from './components/FileUpload';
import { BlockchainExplorer } from './components/BlockchainExplorer';
import { VerificationResult } from './components/VerificationResult';
import { Block, VerificationResult as IVerificationResult } from './types/blockchain';
import { createGenesisBlock, mineBlock } from './utils/blockchain';
import { Shield } from 'lucide-react';

function App() {
  const [blockchain, setBlockchain] = useState<Block[]>([createGenesisBlock()]);
  const [verificationResult, setVerificationResult] = useState<IVerificationResult | null>(null);

  const handleFileHash = useCallback((fileName: string, hash: string) => {
    const data = {
      fileName,
      hash,
      owner: 'Current User' // In a real app, this would come from authentication
    };

    const newBlock = mineBlock(blockchain[blockchain.length - 1], data);
    setBlockchain((prev) => [...prev, newBlock]);

    // Verify the document was added successfully
    const result: IVerificationResult = {
      isValid: true,
      message: `Document "${fileName}" has been successfully added to the blockchain.`,
      block: newBlock
    };
    setVerificationResult(result);
  }, [blockchain]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Shield className="w-16 h-16 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Blockchain Document Verification
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Securely verify and track your documents using blockchain technology.
            Upload a document to add it to the chain and verify its authenticity.
          </p>
        </div>

        <div className="flex flex-col items-center space-y-12">
          <FileUpload onFileHash={handleFileHash} />
          <VerificationResult result={verificationResult} />
          <BlockchainExplorer blocks={blockchain} />
        </div>
      </div>
    </div>
  );
}

export default App;